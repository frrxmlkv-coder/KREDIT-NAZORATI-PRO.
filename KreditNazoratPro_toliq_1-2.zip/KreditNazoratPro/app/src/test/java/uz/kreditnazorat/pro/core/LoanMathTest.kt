package uz.kreditnazorat.pro.core

import org.junit.Assert.*
import org.junit.Test
import kotlin.math.abs

class LoanMathTest {
    private val P = 10_000_000L

    @Test fun annuityPaymentKnownValue() {
        assertTrue(abs(LoanMath.annuityPayment(P, 24.0, 12) - 945_596) <= 1)
    }

    @Test fun zeroRateSplitsEvenly() {
        val s = LoanMath.schedule(1_200_000, 0.0, 12, PaymentType.ANNUITY)
        assertEquals(0L, s.totalInterest)
        assertTrue(s.all { it.payment == 100_000L })
    }

    @Test fun schedulesRepayPrincipalExactly() {
        for (t in PaymentType.values()) {
            val s = LoanMath.schedule(P, 24.0, 12, t)
            assertEquals(12, s.size)
            assertEquals(P, s.sumOf { it.principal })
            assertEquals(0L, s.last().balance)
            assertEquals(P + s.totalInterest, s.totalPaid)
        }
    }

    @Test fun differentialFirstPaymentAndLessInterest() {
        val d = LoanMath.schedule(P, 24.0, 12, PaymentType.DIFFERENTIATED)
        assertEquals(P / 12 + 200_000, d.first().payment)
        assertTrue(d.first().payment > d.last().payment)
        assertTrue(d.totalInterest < LoanMath.schedule(P, 24.0, 12, PaymentType.ANNUITY).totalInterest)
    }

    @Test fun earlyRepaymentShortensTermAndSavesInterest() {
        val r = LoanMath.earlyRepayment(P, 24.0, 12, PaymentType.ANNUITY, 2_000_000)
        assertEquals(8_000_000L, r.newPrincipal)
        assertTrue(r.shortenTerm.months < 12)
        assertTrue(r.shortenTerm.interestSaved > 0)
        assertTrue(r.lowerPayment.firstPayment < 945_596)
        assertEquals(12, r.lowerPayment.months)
        assertTrue(r.lowerPayment.interestSaved > 0)
    }

    @Test fun earlyRepaymentOfWholeDebt() {
        val r = LoanMath.earlyRepayment(P, 24.0, 12, PaymentType.ANNUITY, 50_000_000)
        assertEquals(P, r.extraApplied)
        assertEquals(0, r.shortenTerm.months)
        assertEquals(r.baseInterest, r.shortenTerm.interestSaved)
    }

    @Test fun loadLevelsFollowThresholds() {
        assertEquals(LoanMath.LoadLevel.UNKNOWN, LoanMath.loadLevel(LoanMath.loadPercent(1, 0)))
        assertEquals(LoanMath.LoadLevel.GREEN, LoanMath.loadLevel(LoanMath.loadPercent(3_000_000, 10_000_000)))
        assertEquals(LoanMath.LoadLevel.YELLOW, LoanMath.loadLevel(LoanMath.loadPercent(4_000_000, 10_000_000)))
        assertEquals(LoanMath.LoadLevel.YELLOW, LoanMath.loadLevel(LoanMath.loadPercent(5_000_000, 10_000_000)))
        assertEquals(LoanMath.LoadLevel.RED, LoanMath.loadLevel(LoanMath.loadPercent(5_100_000, 10_000_000)))
    }

    @Test fun safeExtraIsHalfOfFreeFundsAndNeverNegative() {
        assertEquals(1_000_000L, LoanMath.safeExtraPayment(LoanMath.freeFunds(10_000_000, 5_000_000, 2_000_000, 1_000_000)))
        assertEquals(0L, LoanMath.safeExtraPayment(-500))
    }
}

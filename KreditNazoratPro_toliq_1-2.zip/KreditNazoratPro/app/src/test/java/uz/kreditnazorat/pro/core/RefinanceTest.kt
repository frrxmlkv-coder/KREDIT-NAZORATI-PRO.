package uz.kreditnazorat.pro.core

import org.junit.Assert.*
import org.junit.Test

class RefinanceTest {
    @Test fun cheaperRateWithSmallFeeIsBeneficial() {
        val old = listOf(OldLoan(10_000_000, 36.0, 12, PaymentType.ANNUITY, 1_000_000))
        val r = Refinance.evaluate(old, NewLoanTerms(20.0, 12, PaymentType.ANNUITY, commission = 100_000))
        assertTrue(r.beneficial)
        assertTrue(r.netGain > 0)
        assertEquals(10_000_000L, r.mergedPrincipal)
    }

    @Test fun longerHigherRateLoanIsHarmfulEvenIfMonthlyDrops() {
        val old = listOf(OldLoan(10_000_000, 20.0, 12, PaymentType.ANNUITY, 927_000))
        val r = Refinance.evaluate(old, NewLoanTerms(30.0, 36, PaymentType.ANNUITY, commission = 200_000))
        assertFalse(r.beneficial)
        assertTrue(r.monthlySaving > 0)
        assertTrue(r.cheaperMonthlyButCostlier)
    }

    @Test fun newRateNeedNotBeLowerThanEveryOldRate() {
        // Kichik foizli (10%) va yuqori foizli (50%) kreditlar birlashadi, yangi stavka 25%.
        val old = listOf(
            OldLoan(5_000_000, 10.0, 12, PaymentType.ANNUITY, 440_000),
            OldLoan(5_000_000, 50.0, 12, PaymentType.ANNUITY, 570_000)
        )
        val r = Refinance.evaluate(old, NewLoanTerms(25.0, 12, PaymentType.ANNUITY, commission = 50_000))
        assertEquals(10_000_000L, r.mergedPrincipal)
        assertEquals(r.oldTotalCost - r.newTotalCost, r.netGain)
    }

    @Test fun insuranceAndFeesAreIncludedInNewCost() {
        val old = listOf(OldLoan(10_000_000, 24.0, 12, PaymentType.ANNUITY, 945_596))
        val plain = Refinance.evaluate(old, NewLoanTerms(24.0, 12, PaymentType.ANNUITY))
        val withCosts = Refinance.evaluate(old, NewLoanTerms(24.0, 12, PaymentType.ANNUITY,
            commission = 100_000, monthlyInsurance = 10_000, otherCosts = 50_000))
        assertEquals(100_000 + 50_000 + 120_000L, withCosts.newTotalCost - plain.newTotalCost)
    }
}

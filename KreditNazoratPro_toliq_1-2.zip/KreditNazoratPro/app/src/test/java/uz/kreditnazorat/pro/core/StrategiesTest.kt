package uz.kreditnazorat.pro.core

import org.junit.Assert.*
import org.junit.Test

class StrategiesTest {
    private val debts = listOf(
        Debt(1, "Katta, qimmat", 5_000_000, 40.0, 300_000),
        Debt(2, "Kichik, arzon", 1_000_000, 10.0, 100_000)
    )

    @Test fun avalancheBeatsSnowballBeatsMinimums() {
        val c = DebtStrategies.compare(debts, 200_000)
        assertTrue(c.avalanche.completed && c.snowball.completed && c.baseline.completed)
        assertTrue(c.avalanche.totalInterest < c.snowball.totalInterest)
        assertTrue(c.snowball.totalInterest < c.baseline.totalInterest)
        assertTrue(c.avalanche.months <= c.baseline.months)
        assertTrue(c.avalancheSaved > c.snowballSaved)
    }

    @Test fun snowballClosesSmallestFirstAndAvalancheHighestRateFirst() {
        assertEquals(2L, DebtStrategies.simulate(debts, 200_000, Strategy.SNOWBALL).payoffOrder.first())
        val av = DebtStrategies.simulate(debts, 200_000, Strategy.AVALANCHE)
        assertEquals(500_000L, av.firstMonthAllocation[1])   // 300 000 minimal + 200 000 qo'shimcha
        assertEquals(100_000L, av.firstMonthAllocation[2])
    }

    @Test fun uncoverableMinimumIsReportedAsIncomplete() {
        val bad = listOf(Debt(1, "X", 10_000_000, 60.0, 100_000))   // oylik foiz 500 000 > to'lov
        assertFalse(DebtStrategies.simulate(bad, 0, null).completed)
    }

    @Test fun emptyDebtListFinishesImmediately() {
        val r = DebtStrategies.simulate(emptyList(), 100_000, Strategy.AVALANCHE)
        assertEquals(0, r.months); assertTrue(r.completed)
    }
}

package uz.kreditnazorat.pro.data

class Repository(private val db: AppDatabase) {
    val loans = db.loanDao().observeAll()
    val payments = db.paymentDao().observeAll()
    val budget = db.budgetDao().observe()

    suspend fun addLoan(loan: LoanEntity) = db.loanDao().insert(loan)
    suspend fun updateLoan(loan: LoanEntity) = db.loanDao().update(loan)
    suspend fun deleteLoan(loan: LoanEntity) = db.loanDao().delete(loan)
    suspend fun addPayment(p: PaymentEntity) = db.paymentDao().insert(p)
    suspend fun updatePayment(p: PaymentEntity) = db.paymentDao().update(p)
    suspend fun saveBudget(b: BudgetEntity) = db.budgetDao().upsert(b)
}

object UzbekBanks {
    val list = listOf(
        "Milliy bank", "Uzum Bank", "TBC Bank", "Alif", "AVO", "Anorbank",
        "SQB", "Ipoteka bank", "Agrobank", "Hamkorbank", "Boshqa bank"
    )
}

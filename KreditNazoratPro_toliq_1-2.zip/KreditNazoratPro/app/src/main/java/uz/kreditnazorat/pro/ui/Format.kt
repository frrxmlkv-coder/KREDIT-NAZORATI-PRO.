package uz.kreditnazorat.pro.ui

import java.time.LocalDate

fun formatUzs(v: Long): String =
    "%,d".format(v).replace(',', ' ') + " so'm"

fun formatDay(epochDay: Long): String =
    LocalDate.ofEpochDay(epochDay).let { "%02d.%02d.%d".format(it.dayOfMonth, it.monthValue, it.year) }

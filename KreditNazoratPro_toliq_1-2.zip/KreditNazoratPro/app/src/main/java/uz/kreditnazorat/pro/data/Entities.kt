package uz.kreditnazorat.pro.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** Barcha summalar butun so'mda (Long). Sanalar LocalDate.toEpochDay(). */
@Entity(tableName = "loans")
data class LoanEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bankName: String,
    val loanType: String,
    val originalAmount: Long,
    val remainingPrincipal: Long,
    val annualRatePercent: Double,
    val monthlyPayment: Long,
    val startEpochDay: Long,
    val endEpochDay: Long,
    val paymentDay: Int,
    val paymentType: String,          // ANNUITY yoki DIFFERENTIATED
    val termMonths: Int,
    val overdueAmount: Long = 0,
    val monthlyFees: Long = 0,        // komissiya + sug'urta (oylik)
    val note: String = "",
    val isClosed: Boolean = false
)

@Entity(
    tableName = "payments",
    foreignKeys = [ForeignKey(
        entity = LoanEntity::class, parentColumns = ["id"],
        childColumns = ["loanId"], onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("loanId")]
)
data class PaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val loanId: Long,
    val dueEpochDay: Long,
    val amount: Long,
    val paid: Boolean = false,
    val paidEpochDay: Long? = null
)

/** Yagona qator (id = 1): oylik byudjet. */
@Entity(tableName = "budget")
data class BudgetEntity(
    @PrimaryKey val id: Int = 1,
    val monthlyIncome: Long = 0,
    val familyExpenses: Long = 0,
    val savings: Long = 0,
    val extraPaymentBudget: Long = 0
)

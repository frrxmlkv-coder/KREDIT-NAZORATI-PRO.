package uz.kreditnazorat.pro.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import uz.kreditnazorat.pro.data.*

class MainViewModel(private val repo: Repository) : ViewModel() {
    val loans = repo.loans.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val budget = repo.budget.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun addLoan(l: LoanEntity) = viewModelScope.launch { repo.addLoan(l) }
    fun deleteLoan(l: LoanEntity) = viewModelScope.launch { repo.deleteLoan(l) }
    fun saveBudget(b: BudgetEntity) = viewModelScope.launch { repo.saveBudget(b) }

    companion object {
        fun factory(repo: Repository): ViewModelProvider.Factory =
            viewModelFactory { initializer { MainViewModel(repo) } }
    }
}

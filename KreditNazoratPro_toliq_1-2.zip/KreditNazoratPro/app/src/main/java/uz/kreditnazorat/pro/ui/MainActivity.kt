package uz.kreditnazorat.pro.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import uz.kreditnazorat.pro.KreditApp
import uz.kreditnazorat.pro.ui.theme.KreditTheme

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("home", "Bosh sahifa", Icons.Default.Home),
    Tab("loans", "Kreditlar", Icons.Default.List),
    Tab("analysis", "Tahlil", Icons.Default.Info),
    Tab("calc", "Kalkulyator", Icons.Default.Build),
    Tab("settings", "Sozlamalar", Icons.Default.Settings)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repo = (application as KreditApp).repository
        setContent {
            KreditTheme {
                val vm: MainViewModel = viewModel(factory = MainViewModel.factory(repo))
                AppRoot(vm)
            }
        }
    }
}

@Composable
private fun AppRoot(vm: MainViewModel) {
    val nav = rememberNavController()
    val current = nav.currentBackStackEntryAsState().value?.destination?.route
    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEach { t ->
                    NavigationBarItem(
                        selected = current == t.route,
                        onClick = {
                            nav.navigate(t.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true; restoreState = true
                            }
                        },
                        icon = { Icon(t.icon, null) },
                        label = { Text(t.label, maxLines = 1) }
                    )
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = "loans", modifier = Modifier.padding(pad)) {
            composable("home") { Pending("Bosh sahifa (dashboard)", 3) }
            composable("loans") { LoansScreen(vm) }
            composable("analysis") { Pending("Moliyaviy tahlil", 3) }
            composable("calc") { Pending("Kredit kalkulyatori", 3) }
            composable("settings") { Pending("Sozlamalar", 4) }
        }
    }
}

@Composable
private fun Pending(title: String, stage: Int) {
    Box(Modifier.fillMaxSize(), Alignment.Center) {
        Text("$title — $stage-bosqichda qo'shiladi", Modifier.padding(24.dp))
    }
}

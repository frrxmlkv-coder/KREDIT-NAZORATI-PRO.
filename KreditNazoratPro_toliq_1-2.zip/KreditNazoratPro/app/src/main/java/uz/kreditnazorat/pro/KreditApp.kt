package uz.kreditnazorat.pro

import android.app.Application
import uz.kreditnazorat.pro.data.AppDatabase
import uz.kreditnazorat.pro.data.Repository

class KreditApp : Application() {
    val repository by lazy { Repository(AppDatabase.get(this)) }
}

package uz.kreditnazorat.pro.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NavyDark = Color(0xFF0D2B5E)
val Positive = Color(0xFF1E9E5A)
val Warning = Color(0xFFF2B01E)
val Danger = Color(0xFFD64545)

private val Colors = lightColorScheme(
    primary = NavyDark, onPrimary = Color.White,
    secondary = Positive, error = Danger,
    background = Color(0xFFF5F7FB), surface = Color.White
)

@Composable
fun KreditTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = Colors, content = content)

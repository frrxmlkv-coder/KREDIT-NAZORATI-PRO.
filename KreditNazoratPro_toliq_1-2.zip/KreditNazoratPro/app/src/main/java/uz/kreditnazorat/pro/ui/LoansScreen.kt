package uz.kreditnazorat.pro.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import uz.kreditnazorat.pro.data.LoanEntity
import uz.kreditnazorat.pro.data.UzbekBanks
import java.time.LocalDate

@Composable
fun LoansScreen(vm: MainViewModel) {
    val loans by vm.loans.collectAsStateWithLifecycle()
    var showAdd by remember { mutableStateOf(false) }
    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, "Qo'shish") }
        }
    ) { pad ->
        if (loans.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad).padding(24.dp)) {
                Text("Hozircha kredit yo'q. «+» tugmasi bilan qo'shing.")
            }
        } else {
            LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(loans, key = { it.id }) { LoanCard(it) { vm.deleteLoan(it) } }
            }
        }
    }
    if (showAdd) AddLoanDialog(onDismiss = { showAdd = false }) { vm.addLoan(it); showAdd = false }
}

@Composable
private fun LoanCard(l: LoanEntity, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row {
                Column(Modifier.weight(1f)) {
                    Text(l.bankName, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(l.loanType + " • " + if (l.paymentType == "ANNUITY") "annuitet" else "differensial")
                }
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "O'chirish") }
            }
            Spacer(Modifier.height(8.dp))
            Text("Qoldiq: " + formatUzs(l.remainingPrincipal), fontWeight = FontWeight.SemiBold, fontSize = 20.sp)
            Text("Oylik to'lov: " + formatUzs(l.monthlyPayment))
            Text("Yillik foiz: ${l.annualRatePercent}% • Har oyning ${l.paymentDay}-kuni")
            Text("Tugash: " + formatDay(l.endEpochDay))
        }
    }
}

@Composable
private fun AddLoanDialog(onDismiss: () -> Unit, onSave: (LoanEntity) -> Unit) {
    var bank by remember { mutableStateOf(UzbekBanks.list.first()) }
    var customBank by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var type by remember { mutableStateOf("Iste'mol krediti") }
    var amount by remember { mutableStateOf("") }
    var remaining by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }
    var payment by remember { mutableStateOf("") }
    var term by remember { mutableStateOf("") }
    var day by remember { mutableStateOf("1") }
    var annuity by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    val num = KeyboardOptions(keyboardType = KeyboardType.Number)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Kredit qo'shish") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box {
                    OutlinedButton(onClick = { menu = true }, Modifier.fillMaxWidth()) { Text("Bank: $bank") }
                    DropdownMenu(menu, { menu = false }) {
                        UzbekBanks.list.forEach { b -> DropdownMenuItem(text = { Text(b) }, onClick = { bank = b; menu = false }) }
                    }
                }
                if (bank == "Boshqa bank")
                    OutlinedTextField(customBank, { customBank = it }, label = { Text("Bank nomi") }, singleLine = true)
                OutlinedTextField(type, { type = it }, label = { Text("Kredit turi") }, singleLine = true)
                OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Dastlabki summa (so'm)") }, keyboardOptions = num, singleLine = true)
                OutlinedTextField(remaining, { remaining = it.filter(Char::isDigit) }, label = { Text("Qolgan asosiy qarz (bo'sh = dastlabki)") }, keyboardOptions = num, singleLine = true)
                OutlinedTextField(rate, { rate = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Yillik foiz (%)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(payment, { payment = it.filter(Char::isDigit) }, label = { Text("Oylik to'lov (so'm)") }, keyboardOptions = num, singleLine = true)
                OutlinedTextField(term, { term = it.filter(Char::isDigit) }, label = { Text("To'lovlar soni (oy)") }, keyboardOptions = num, singleLine = true)
                OutlinedTextField(day, { day = it.filter(Char::isDigit) }, label = { Text("To'lov kuni (1–28)") }, keyboardOptions = num, singleLine = true)
                Row {
                    FilterChip(annuity, { annuity = true }, label = { Text("Annuitet") })
                    Spacer(Modifier.width(8.dp))
                    FilterChip(!annuity, { annuity = false }, label = { Text("Differensial") })
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = amount.toLongOrNull(); val m = term.toIntOrNull()
                val r = rate.toDoubleOrNull(); val p = payment.toLongOrNull(); val d = day.toIntOrNull()
                val name = if (bank == "Boshqa bank") customBank.trim() else bank
                when {
                    name.isEmpty() -> error = "Bank nomini kiriting"
                    a == null || a <= 0 -> error = "Summani kiriting"
                    r == null || r < 0 -> error = "Foizni kiriting"
                    p == null || p <= 0 -> error = "Oylik to'lovni kiriting"
                    m == null || m <= 0 -> error = "Muddatni kiriting"
                    d == null || d !in 1..28 -> error = "To'lov kuni 1–28 oralig'ida bo'lsin"
                    else -> {
                        val rem = remaining.toLongOrNull() ?: a
                        val start = LocalDate.now()
                        onSave(LoanEntity(
                            bankName = name, loanType = type.trim().ifEmpty { "Kredit" },
                            originalAmount = a, remainingPrincipal = rem.coerceAtMost(a),
                            annualRatePercent = r, monthlyPayment = p,
                            startEpochDay = start.toEpochDay(),
                            endEpochDay = start.plusMonths(m.toLong()).toEpochDay(),
                            paymentDay = d, paymentType = if (annuity) "ANNUITY" else "DIFFERENTIATED",
                            termMonths = m
                        ))
                    }
                }
            }) { Text("Saqlash") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

package uz.kreditnazorat.pro.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface LoanDao {
    @Query("SELECT * FROM loans ORDER BY id DESC")
    fun observeAll(): Flow<List<LoanEntity>>
    @Query("SELECT * FROM loans WHERE id = :id")
    suspend fun getById(id: Long): LoanEntity?
    @Insert suspend fun insert(loan: LoanEntity): Long
    @Update suspend fun update(loan: LoanEntity)
    @Delete suspend fun delete(loan: LoanEntity)
}

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payments ORDER BY dueEpochDay")
    fun observeAll(): Flow<List<PaymentEntity>>
    @Query("SELECT * FROM payments WHERE loanId = :loanId ORDER BY dueEpochDay")
    fun observeForLoan(loanId: Long): Flow<List<PaymentEntity>>
    @Insert suspend fun insert(p: PaymentEntity): Long
    @Insert suspend fun insertAll(p: List<PaymentEntity>)
    @Update suspend fun update(p: PaymentEntity)
}

@Dao
interface BudgetDao {
    @Query("SELECT * FROM budget WHERE id = 1")
    fun observe(): Flow<BudgetEntity?>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(b: BudgetEntity)
}

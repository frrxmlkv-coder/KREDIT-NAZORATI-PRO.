package uz.kreditnazorat.pro.core

import kotlin.math.roundToLong

data class Debt(val id: Long, val name: String, val balance: Long, val annualPercent: Double, val minPayment: Long)

enum class Strategy { AVALANCHE, SNOWBALL }

data class PlanResult(
    val strategy: Strategy?,            // null = faqat minimal to'lovlar (taqqoslash bazasi)
    val months: Int,
    val totalInterest: Long,
    val completed: Boolean,             // false: minimal to'lov foizni yopmaydi yoki 100 yildan oshdi
    val firstMonthAllocation: Map<Long, Long>,
    val payoffOrder: List<Long>,
    val payoffMonth: Map<Long, Int>
)

data class StrategyComparison(val baseline: PlanResult, val avalanche: PlanResult, val snowball: PlanResult) {
    val avalancheSaved get() = baseline.totalInterest - avalanche.totalInterest
    val snowballSaved get() = baseline.totalInterest - snowball.totalInterest
}

object DebtStrategies {
    private const val MAX_MONTHS = 1200

    /**
     * Oylik byudjet = barcha minimal to'lovlar yig'indisi + qo'shimcha summa (o'zgarmas).
     * Yopilgan kreditning bo'shagan minimal to'lovi keyingi maqsadli kreditga o'tadi (rollover).
     * strategy == null: qo'shimcha ham, rollover ham yo'q.
     */
    fun simulate(debts: List<Debt>, extra: Long, strategy: Strategy?): PlanResult {
        val active = debts.filter { it.balance > 0 }
        val bal = HashMap<Long, Double>().apply { active.forEach { put(it.id, it.balance.toDouble()) } }
        val order = when (strategy) {
            Strategy.AVALANCHE -> active.sortedWith(compareByDescending<Debt> { it.annualPercent }.thenBy { it.balance })
            Strategy.SNOWBALL -> active.sortedBy { it.balance }
            null -> active
        }
        val budget = active.sumOf { it.minPayment } + if (strategy != null) extra.coerceAtLeast(0) else 0
        var totalInterest = 0.0
        var month = 0
        val firstAlloc = LinkedHashMap<Long, Long>()
        val payoffMonth = LinkedHashMap<Long, Int>()
        val payoffOrder = ArrayList<Long>()

        while (bal.values.any { it > 0.5 } && month < MAX_MONTHS) {
            month++
            for (d in active) {
                val b = bal.getValue(d.id)
                if (b > 0.5) { val i = b * LoanMath.monthlyRate(d.annualPercent); bal[d.id] = b + i; totalInterest += i }
            }
            var remaining = budget.toDouble()
            val paid = HashMap<Long, Double>()
            for (d in active) {                         // 1) minimal to'lovlar
                val b = bal.getValue(d.id)
                if (b > 0.5) { val p = minOf(d.minPayment.toDouble(), b); bal[d.id] = b - p; remaining -= p; paid[d.id] = p }
            }
            if (strategy != null) {                     // 2) qolgani maqsadli kreditga
                for (d in order) {
                    val b = bal.getValue(d.id)
                    if (b > 0.5 && remaining > 0) {
                        val p = minOf(remaining, b); bal[d.id] = b - p; remaining -= p
                        paid[d.id] = (paid[d.id] ?: 0.0) + p
                    }
                }
            }
            if (month == 1) paid.forEach { (id, v) -> firstAlloc[id] = v.roundToLong() }
            for (d in active) if (bal.getValue(d.id) <= 0.5 && d.id !in payoffMonth) {
                bal[d.id] = 0.0; payoffMonth[d.id] = month; payoffOrder += d.id
            }
        }
        return PlanResult(strategy, month, totalInterest.roundToLong(), bal.values.none { it > 0.5 },
            firstAlloc, payoffOrder, payoffMonth)
    }

    fun compare(debts: List<Debt>, extra: Long) = StrategyComparison(
        simulate(debts, extra, null),
        simulate(debts, extra, Strategy.AVALANCHE),
        simulate(debts, extra, Strategy.SNOWBALL)
    )
}

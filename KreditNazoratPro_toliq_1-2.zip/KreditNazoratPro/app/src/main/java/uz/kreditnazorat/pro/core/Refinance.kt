package uz.kreditnazorat.pro.core

data class OldLoan(
    val balance: Long, val annualPercent: Double, val remainingMonths: Int,
    val type: PaymentType, val currentMonthlyPayment: Long, val monthlyFees: Long = 0
)

data class NewLoanTerms(
    val annualPercent: Double, val months: Int, val type: PaymentType,
    val commission: Long = 0,          // bir martalik
    val monthlyInsurance: Long = 0,    // har oy
    val otherCosts: Long = 0           // bir martalik
)

data class RefinanceResult(
    val mergedPrincipal: Long,
    val currentMonthlyTotal: Long,
    val newMonthlyPayment: Long,       // birinchi oylik to'lov + sug'urta
    val monthlySaving: Long,           // manfiy bo'lsa — oylik to'lov oshadi
    val newTotalRepay: Long,           // asosiy qarz + foiz
    val newTotalInterest: Long,
    val oldTotalCost: Long,            // eski kreditlar bo'yicha qolgan jami to'lov
    val newTotalCost: Long,            // yangi kredit + barcha xarajatlar
    val netGain: Long,                 // oldTotalCost − newTotalCost
    val beneficial: Boolean,
    val cheaperMonthlyButCostlier: Boolean
)

object Refinance {
    /** Mezon: foiz stavkasi emas, barcha xarajatlar qo'shilgandagi umumiy farq (netGain > 0 bo'lsa foydali). */
    fun evaluate(old: List<OldLoan>, new: NewLoanTerms): RefinanceResult {
        val loans = old.filter { it.balance > 0 }
        val merged = loans.sumOf { it.balance }
        val currentMonthly = loans.sumOf { it.currentMonthlyPayment + it.monthlyFees }
        val oldCost = loans.sumOf {
            LoanMath.schedule(it.balance, it.annualPercent, it.remainingMonths, it.type).totalPaid +
                it.monthlyFees * it.remainingMonths
        }
        val rows = if (merged > 0) LoanMath.schedule(merged, new.annualPercent, new.months, new.type) else emptyList()
        val repay = rows.totalPaid
        val newMonthly = (rows.firstOrNull()?.payment ?: 0) + new.monthlyInsurance
        val newCost = repay + new.commission + new.otherCosts + new.monthlyInsurance * new.months
        val gain = oldCost - newCost
        val saving = currentMonthly - newMonthly
        return RefinanceResult(merged, currentMonthly, newMonthly, saving, repay, rows.totalInterest,
            oldCost, newCost, gain, gain > 0, saving > 0 && gain <= 0)
    }
}

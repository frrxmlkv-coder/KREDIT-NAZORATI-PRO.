package uz.kreditnazorat.pro.core

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.ceil
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToLong

enum class PaymentType {
    ANNUITY, DIFFERENTIATED;
    companion object { fun from(s: String) = if (s == "DIFFERENTIATED") DIFFERENTIATED else ANNUITY }
}

data class ScheduleRow(val month: Int, val payment: Long, val interest: Long, val principal: Long, val balance: Long)

val List<ScheduleRow>.totalPaid get() = sumOf { it.payment }
val List<ScheduleRow>.totalInterest get() = sumOf { it.interest }

/** Barcha foizlar YILLIK foizda kiritiladi; oylik stavka = yillik / 12. Hisob so'mda yaxlitlanadi. */
object LoanMath {
    private const val MAX_MONTHS = 1200

    fun monthlyRate(annualPercent: Double) = annualPercent / 100.0 / 12.0

    fun annuityPayment(principal: Long, annualPercent: Double, months: Int): Long {
        require(months > 0) { "Muddat 0 dan katta bo'lsin" }
        if (principal <= 0) return 0
        val r = monthlyRate(annualPercent)
        if (r == 0.0) return (principal.toDouble() / months).roundToLong()
        return (principal * r / (1 - (1 + r).pow(-months))).roundToLong()
    }

    fun schedule(principal: Long, annualPercent: Double, months: Int, type: PaymentType): List<ScheduleRow> {
        require(months > 0) { "Muddat 0 dan katta bo'lsin" }
        if (principal <= 0) return emptyList()
        val r = monthlyRate(annualPercent)
        val fixed = annuityPayment(principal, annualPercent, months)
        val step = principal / months
        var bal = principal
        val rows = ArrayList<ScheduleRow>(months)
        for (m in 1..months) {
            val interest = (bal * r).roundToLong()
            val part = when {
                m == months -> bal   // oxirgi oyda qoldiq to'liq yopiladi
                type == PaymentType.ANNUITY -> min(bal, (fixed - interest).coerceAtLeast(0))
                else -> min(bal, step)
            }
            bal -= part
            rows += ScheduleRow(m, part + interest, interest, part, bal)
        }
        return rows
    }

    /** Berilgan sanagacha qolgan to'liq oylar (kamida 1, agar qarz bor bo'lsa). */
    fun remainingMonths(endEpochDay: Long, todayEpochDay: Long = LocalDate.now().toEpochDay()): Int {
        val m = ChronoUnit.MONTHS.between(LocalDate.ofEpochDay(todayEpochDay), LocalDate.ofEpochDay(endEpochDay)).toInt()
        return m.coerceAtLeast(1)
    }

    // ---------- Muddatidan oldin yopish ----------

    data class EarlyOption(val months: Int, val firstPayment: Long, val totalInterest: Long,
                           val interestSaved: Long, val monthsSaved: Int)

    data class EarlyResult(val extraApplied: Long, val newPrincipal: Long, val baseInterest: Long,
                           val shortenTerm: EarlyOption, val lowerPayment: EarlyOption)

    /** Qo'shimcha summa to'liq ASOSIY QARZGA yo'naltiriladi (foizga emas). */
    fun earlyRepayment(principal: Long, annualPercent: Double, remainingMonths: Int,
                       type: PaymentType, extra: Long): EarlyResult {
        val base = schedule(principal, annualPercent, remainingMonths, type)
        val baseInterest = base.totalInterest
        val applied = extra.coerceIn(0, principal)
        val newP = principal - applied
        if (newP == 0L) {
            val o = EarlyOption(0, 0, 0, baseInterest, remainingMonths)
            return EarlyResult(applied, 0, baseInterest, o, o)
        }
        val r = monthlyRate(annualPercent)
        val fixed = annuityPayment(principal, annualPercent, remainingMonths)
        val step = (principal / remainingMonths).coerceAtLeast(1)
        // 1) To'lov o'zgarmaydi, muddat qisqaradi
        var bal = newP; var interestSum = 0L; var months = 0; var first = 0L
        while (bal > 0 && months < MAX_MONTHS) {
            months++
            val interest = (bal * r).roundToLong()
            val want = if (type == PaymentType.ANNUITY) (fixed - interest).coerceAtLeast(0) else step
            val part = if (want == 0L) 0L else min(bal, want)
            bal -= part; interestSum += interest
            if (months == 1) first = part + interest
        }
        val shorten = EarlyOption(months, first, interestSum, baseInterest - interestSum, remainingMonths - months)
        // 2) Muddat o'zgarmaydi, oylik to'lov kamayadi
        val lower = schedule(newP, annualPercent, remainingMonths, type)
        val lowOpt = EarlyOption(remainingMonths, lower.first().payment, lower.totalInterest,
            baseInterest - lower.totalInterest, 0)
        return EarlyResult(applied, newP, baseInterest, shorten, lowOpt)
    }

    // ---------- Kredit yuklamasi ----------

    enum class LoadLevel { UNKNOWN, GREEN, YELLOW, RED }

    /** Kredit yuklamasi = jami oylik kredit to'lovlari / oylik daromad × 100. Daromad 0 bo'lsa null. */
    fun loadPercent(totalMonthlyPayments: Long, monthlyIncome: Long): Double? =
        if (monthlyIncome <= 0) null else totalMonthlyPayments * 100.0 / monthlyIncome

    fun loadLevel(percent: Double?): LoadLevel = when {
        percent == null -> LoadLevel.UNKNOWN
        percent <= 30.0 -> LoadLevel.GREEN
        percent <= 50.0 -> LoadLevel.YELLOW
        else -> LoadLevel.RED
    }

    /** Bo'sh mablag' = daromad − oilaviy xarajat − kredit to'lovlari − jamg'arma. */
    fun freeFunds(income: Long, family: Long, loanPayments: Long, savings: Long) =
        income - family - loanPayments - savings

    /** Xavfsiz qo'shimcha to'lov: bo'sh mablag'ning yarmi (qolgan yarmi zaxira). Manfiy bo'lmaydi. */
    fun safeExtraPayment(freeFunds: Long): Long = if (freeFunds <= 0) 0 else freeFunds / 2
}

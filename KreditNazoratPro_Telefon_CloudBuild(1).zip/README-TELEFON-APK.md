# KreditNazoratPro — telefon orqali APK yig‘ish

Loyiha Android/Kotlin/Jetpack Compose formatida. APK hali yig‘ilmagan.

## GitHub Actions orqali
1. ZIPni telefonda chiqarib oling.
2. GitHub’da yangi repository yarating.
3. ZIP ichidagi `KreditNazoratPro` papkasining ICHIDAGI barcha fayl va papkalarni repository rootiga yuklang (masalan, `app/`, `build.gradle.kts`, `settings.gradle.kts`).
4. `.github/workflows/android.yml` fayli ham yuklanganini tekshiring.
5. Repository → Actions → Android APK Build → Run workflow.
6. Build tugagach, workflow run sahifasidan Artifacts bo‘limidagi `KreditNazoratPro-debug-apk` ni yuklab oling.
7. Yuklangan artifact ZIPni oching; ichidan `app-debug.apk` ni o‘rnating.

Eslatma: build xato bersa, Actions sahifasidagi qizil xato matni yoki skrinshotni yuboring.
